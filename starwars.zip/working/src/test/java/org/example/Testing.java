package org.example;

import org.example.connection.ConnectionManager;
import org.example.dto.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class Testing {
	private static StarshipDTO starshipDTO;
	private static PeopleDTO peopleDTO;
	private static FilmDTO filmsDTO;
	private static VehicleDTO vehicleDTO;
	private static SpeciesDTO speciesDTO;
	private ConnectionManager connectionManger;

	@BeforeAll
	public static void setup() {
		ConnectionManager connectionManager = new ConnectionManager();
		starshipDTO = Injector.injectStarshipDTO("https://swapi.dev/api/starships/3/");
		peopleDTO = Injector.injectPeopleDTO("https://swapi.dev/api/people/1/");
		filmsDTO = Injector.injectFilmsDTO("https://swapi.dev/api/films/1/");
		vehicleDTO = Injector.injectVehiclesDTO("https://swapi.dev/api/vehicles/4/");
		speciesDTO= Injector.injectSpeciesDTO("https://swapi.dev/api/species/9/");
	}

    @Test
	@DisplayName("test response code")
	void testResponseCode() {
		Assertions.assertEquals(200, connectionManger.getStatusCode());
	}

	@Test
	@DisplayName("getting name of starship")
	void getNameOfStarship() {
		Assertions.assertEquals("Star Destroyer",starshipDTO.getName());
	}

    @Test
    @DisplayName("getting manufacturer of starship")
    void getManufacturerOfStarship() {
        Assertions.assertEquals("Kuat Drive Yards",starshipDTO.getManufacturer());
    }

    @Test
    @DisplayName("getting height of people")
	void getHeight(){
		Assertions.assertEquals("172", peopleDTO.getHeight());
	}

    @Test
    @DisplayName("getting birth year")
    void getBirthYear(){
        Assertions.assertEquals("19BBY", peopleDTO.getBirthYear());
    }

	@Test
	@DisplayName("get director of film")
	void getDirectorOfFilm(){
		Assertions.assertEquals("George Lucas", filmsDTO.getDirector());
	}

    @Test
    @DisplayName("get title of film")
    void getTitleOfFilm(){
        Assertions.assertEquals("A New Hope", filmsDTO.getTitle());
    }

	@Test
	@DisplayName("get the model of vehicle")
	void getModelOfVehicle(){
		Assertions.assertEquals("Digger Crawler", vehicleDTO.getModel());
	}

	@Test
	@DisplayName("get the species classification")
	void getSpeciesClassification(){
		Assertions.assertEquals("mammal", speciesDTO.getClassification());
	}



}