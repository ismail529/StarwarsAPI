package org.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.dto.*;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class Injector {

    public static StarshipDTO injectStarshipDTO(String url) {
        StarshipDTO starshipDTO = new StarshipDTO();
        ObjectMapper objectMapper = new ObjectMapper();
        HttpClient httpClient = HttpClient.newHttpClient();
        HttpRequest httpRequest = HttpRequest.newBuilder().uri(URI.create(url)).build();
        try {
            HttpResponse<String> httpResponse = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            starshipDTO = objectMapper.readValue(httpResponse.body(), StarshipDTO.class);
        }catch (IOException|InterruptedException e) {
            e.printStackTrace();
        }
        return starshipDTO;
    }

    public static PeopleDTO injectPeopleDTO(String url){
        PeopleDTO peopleDTO = new PeopleDTO();
        ObjectMapper objectMapper = new ObjectMapper();
        HttpClient httpClient = HttpClient.newHttpClient();
        HttpRequest httpRequest = HttpRequest.newBuilder().uri(URI.create(url)).build();

        try {
            HttpResponse<String> httpResponse = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            peopleDTO = objectMapper.readValue(httpResponse.body(), PeopleDTO.class);
        }catch (IOException | InterruptedException e){
            e.printStackTrace();
        }
        return peopleDTO;
    }

    public static FilmDTO injectFilmsDTO(String url){
        FilmDTO filmsDTO = new FilmDTO();
        ObjectMapper objectMapper = new ObjectMapper();
        HttpClient httpClient = HttpClient.newHttpClient();
        HttpRequest httpRequest = HttpRequest.newBuilder().uri(URI.create(url)).build();

        try {
            HttpResponse<String> httpResponse = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            filmsDTO = objectMapper.readValue(httpResponse.body(), FilmDTO.class);
        }catch (IOException | InterruptedException e){
            e.printStackTrace();
        }
        return filmsDTO;
    }

    public static VehicleDTO injectVehiclesDTO(String url){
        VehicleDTO vehiclesDTO = new VehicleDTO();
        ObjectMapper objectMapper = new ObjectMapper();
        HttpClient httpClient = HttpClient.newHttpClient();
        HttpRequest httpRequest = HttpRequest.newBuilder().uri(URI.create(url)).build();

        try {
            HttpResponse<String> httpResponse = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            vehiclesDTO = objectMapper.readValue(httpResponse.body(), VehicleDTO.class);
        }catch (IOException | InterruptedException e){
            e.printStackTrace();
        }
        return vehiclesDTO;
    }

    public static SpeciesDTO injectSpeciesDTO(String url){
        SpeciesDTO speciesDTO = new SpeciesDTO();
        ObjectMapper objectMapper = new ObjectMapper();
        HttpClient httpClient = HttpClient.newHttpClient();
        HttpRequest httpRequest = HttpRequest.newBuilder().uri(URI.create(url)).build();

        try {
            HttpResponse<String> httpResponse = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            speciesDTO = objectMapper.readValue(httpResponse.body(), SpeciesDTO.class);
        }catch (IOException | InterruptedException e){
            e.printStackTrace();
        }
        return speciesDTO;
    }
}