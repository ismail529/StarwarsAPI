package org.example.connection;


import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpHeaders;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.Map;


public class ConnectionManager {
    private static HttpResponse<String> httpResponse = null;
    static HttpClient httpClient = HttpClient.newHttpClient();
    static HttpRequest httpRequest = HttpRequest.newBuilder()
        .uri(URI.create("https://swapi.dev/api"))
        .build();
    private static final String baseUrl = "https://swapi.dev/api/";
    private static String endPoint = "people/1/";
    public static int getStatusCode(){
        HttpClient httpClient = HttpClient.newHttpClient();
        HttpRequest httpRequest = HttpRequest.newBuilder().uri(URI.create(baseUrl+ endPoint)).build();
        int statusCode=0;
        try {
            HttpResponse<String> httpResponse = httpClient.send(httpRequest,HttpResponse.BodyHandlers.ofString());
            statusCode = httpResponse.statusCode();
        }   catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return statusCode;
    }
    public static List<String> getHeader() throws IOException,InterruptedException {
        HttpResponse<String> httpResponse = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
        HttpHeaders header = httpResponse.headers();
        Map<String,List<String>> map = header.map();
        return header.allValues("Server");
    }
    public String getURL(){
        return baseUrl+ endPoint;
    }
    public static String getConnection() {
        return baseUrl;
    }

}
