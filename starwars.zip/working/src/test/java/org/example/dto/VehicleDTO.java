package org.example.dto;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "cargo_capacity",
        "consumables",
        "cost_in_credits",
        "created",
        "crew",
        "edited",
        "length",
        "manufacturer",
        "max_atmosphering_speed",
        "model",
        "name",
        "passengers",
        "pilots",
        "films",
        "url",
        "vehicle_class"
})
public class VehicleDTO {

    @JsonProperty("cargo_capacity")
    private String cargoCapacity;
    @JsonProperty("consumables")
    private String consumables;
    @JsonProperty("cost_in_credits")
    private String costInCredits;
    @JsonProperty("created")
    private String created;
    @JsonProperty("crew")
    private String crew;
    @JsonProperty("edited")
    private String edited;
    @JsonProperty("length")
    private String length;
    @JsonProperty("manufacturer")
    private String manufacturer;
    @JsonProperty("max_atmosphering_speed")
    private String maxAtmospheringSpeed;
    @JsonProperty("model")
    private String model;
    @JsonProperty("name")
    private String name;
    @JsonProperty("passengers")
    private String passengers;
    @JsonProperty("pilots")
    private List<Object> pilots = null;
    @JsonProperty("films")
    private List<String> films = null;
    @JsonProperty("url")
    private String url;
    @JsonProperty("vehicle_class")
    private String vehicleClass;

    /**
     * No args constructor for use in serialization
     *
     */
    public VehicleDTO() {
    }

    /**
     *
     * @param films
     * @param passengers
     * @param pilots
     * @param edited
     * @param consumables
     * @param created
     * @param length
     * @param costInCredits
     * @param cargoCapacity
     * @param url
     * @param crew
     * @param manufacturer
     * @param maxAtmospheringSpeed
     * @param name
     * @param vehicleClass
     * @param model
     */
    public VehicleDTO(String cargoCapacity, String consumables, String costInCredits, String created, String crew, String edited, String length, String manufacturer, String maxAtmospheringSpeed, String model, String name, String passengers, List<Object> pilots, List<String> films, String url, String vehicleClass) {
        super();
        this.cargoCapacity = cargoCapacity;
        this.consumables = consumables;
        this.costInCredits = costInCredits;
        this.created = created;
        this.crew = crew;
        this.edited = edited;
        this.length = length;
        this.manufacturer = manufacturer;
        this.maxAtmospheringSpeed = maxAtmospheringSpeed;
        this.model = model;
        this.name = name;
        this.passengers = passengers;
        this.pilots = pilots;
        this.films = films;
        this.url = url;
        this.vehicleClass = vehicleClass;
    }

    @JsonProperty("cargo_capacity")
    public String getCargoCapacity() {
        return cargoCapacity;
    }

    @JsonProperty("cargo_capacity")
    public void setCargoCapacity(String cargoCapacity) {
        this.cargoCapacity = cargoCapacity;
    }

    @JsonProperty("consumables")
    public String getConsumables() {
        return consumables;
    }

    @JsonProperty("consumables")
    public void setConsumables(String consumables) {
        this.consumables = consumables;
    }

    @JsonProperty("cost_in_credits")
    public String getCostInCredits() {
        return costInCredits;
    }

    @JsonProperty("cost_in_credits")
    public void setCostInCredits(String costInCredits) {
        this.costInCredits = costInCredits;
    }

    @JsonProperty("created")
    public String getCreated() {
        return created;
    }

    @JsonProperty("created")
    public void setCreated(String created) {
        this.created = created;
    }

    @JsonProperty("crew")
    public String getCrew() {
        return crew;
    }

    @JsonProperty("crew")
    public void setCrew(String crew) {
        this.crew = crew;
    }

    @JsonProperty("edited")
    public String getEdited() {
        return edited;
    }

    @JsonProperty("edited")
    public void setEdited(String edited) {
        this.edited = edited;
    }

    @JsonProperty("length")
    public String getLength() {
        return length;
    }

    @JsonProperty("length")
    public void setLength(String length) {
        this.length = length;
    }

    @JsonProperty("manufacturer")
    public String getManufacturer() {
        return manufacturer;
    }

    @JsonProperty("manufacturer")
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    @JsonProperty("max_atmosphering_speed")
    public String getMaxAtmospheringSpeed() {
        return maxAtmospheringSpeed;
    }

    @JsonProperty("max_atmosphering_speed")
    public void setMaxAtmospheringSpeed(String maxAtmospheringSpeed) {
        this.maxAtmospheringSpeed = maxAtmospheringSpeed;
    }

    @JsonProperty("model")
    public String getModel() {
        return model;
    }

    @JsonProperty("model")
    public void setModel(String model) {
        this.model = model;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("passengers")
    public String getPassengers() {
        return passengers;
    }

    @JsonProperty("passengers")
    public void setPassengers(String passengers) {
        this.passengers = passengers;
    }

    @JsonProperty("pilots")
    public List<Object> getPilots() {
        return pilots;
    }

    @JsonProperty("pilots")
    public void setPilots(List<Object> pilots) {
        this.pilots = pilots;
    }

    @JsonProperty("films")
    public List<String> getFilms() {
        return films;
    }

    @JsonProperty("films")
    public void setFilms(List<String> films) {
        this.films = films;
    }

    @JsonProperty("url")
    public String getUrl() {
        return url;
    }

    @JsonProperty("url")
    public void setUrl(String url) {
        this.url = url;
    }

    @JsonProperty("vehicle_class")
    public String getVehicleClass() {
        return vehicleClass;
    }

    @JsonProperty("vehicle_class")
    public void setVehicleClass(String vehicleClass) {
        this.vehicleClass = vehicleClass;
    }

}